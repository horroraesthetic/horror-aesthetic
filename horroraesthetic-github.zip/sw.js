/* HORROR AESTHETIC service worker — resilient offline handling */
const CACHE_NAME = "ha-v154";
const SITE_ROOT = "/horror-aesthetic/";
const APP_SHELL = [
  SITE_ROOT,
  SITE_ROOT + "index.html",
  SITE_ROOT + "manifest.webmanifest",
  SITE_ROOT + "favicon-48.png",
  SITE_ROOT + "offline.html"
];

self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);

    // Cache shell resources independently: one optional/missing asset must
    // not prevent the new service worker from installing.
    await Promise.allSettled(
      APP_SHELL.map(async path => {
        const response = await fetch(path, { cache: "reload" });
        if (!response.ok) throw new Error(`Precache failed: ${path}`);
        await cache.put(path, response);
      })
    );

    await self.skipWaiting();
  })());
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const cacheNames = await caches.keys();
    await Promise.all(
      cacheNames
        .filter(name => name.startsWith("ha-v") && name !== CACHE_NAME)
        .map(name => caches.delete(name))
    );
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", event => {
  const request = event.request;

  if (request.method !== "GET" || request.headers.has("range")) return;

  const url = new URL(request.url);
  if (
    url.origin !== self.location.origin ||
    !url.pathname.startsWith(SITE_ROOT) ||
    url.pathname.startsWith(SITE_ROOT + "media/")
  ) return;

  const networkFirst =
    request.mode === "navigate" ||
    url.pathname.endsWith("/updates.json") ||
    url.pathname.endsWith("/sw.js");

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);

    if (networkFirst) {
      try {
        const response = await fetch(request);
        if (response.ok && response.type === "basic") {
          await cache.put(request, response.clone());
        }
        return response;
      } catch {
        const cached = await cache.match(request);
        if (cached) return cached;

        if (request.mode === "navigate") {
          const offlinePage = await cache.match(SITE_ROOT + "offline.html");
          if (offlinePage) return offlinePage;
        }

        return new Response("Offline — this resource is not cached yet.", {
          status: 503,
          statusText: "Service Unavailable",
          headers: { "Content-Type": "text/plain; charset=utf-8" }
        });
      }
    }

    const cached = await cache.match(request);
    if (cached) return cached;

    const response = await fetch(request);
    if (response.ok && response.type === "basic") {
      await cache.put(request, response.clone());
    }
    return response;
  })());
});
